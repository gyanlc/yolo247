const fontFamily = {
  poppins: 'Poppins, Arial, Helvetica, sans-serif',
  inter: 'Inter, Verdana, sans-serif',
}

export default fontFamily
