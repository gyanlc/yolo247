const breakpoints = {
  md: '768px',
  lg: '1024px',
  xl: '1440px',
}

export default breakpoints
